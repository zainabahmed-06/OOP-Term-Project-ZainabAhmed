﻿#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include "Map.h"
#include "Tower.h"
#include "CannonTower.h"
#include "SniperTower.h"
#include "MachineGunTower.h"
#include "SlowTower.h"
#include "BasicEnemy.h"
#include "FastEnemy.h"
#include "TankEnemy.h"
#include "FlyingEnemy.h"

struct WaveData {
    int basicCount;
    int fastCount;
    int flyingCount;
    int tankCount;
};

static const int max_waves = 5;
static const int max_towers = 32;
static const int max_enemies = 64;

enum class TowerType { Cannon, Sniper, MachineGun, Slow, None };

class Game {
public:
    Game();
    ~Game();

    void run();  

private:
    bool mGameWon;
    bool mGameOver;
    RenderWindow mWindow;

    WaveData mWaveData[max_waves];
    int mBasicLeft;
    int mFastLeft;
    int mFlyingLeft;
    int mTankLeft;

    struct TowerCard {
        TowerType type;
        string name;
        int cost;
        RectangleShape cardBg;
        Sprite icon;
    };
    static const int shop_width = 200;
    static const int cards = 4;
    TowerCard mCards[cards];

    bool mDragging;
    TowerType mDragType;
    Sprite  mDragSprite;
    Vector2f mDragOffset;

    void buildSidebar();
    void drawSidebar();

    Map mMap;

    Tower* mTowers[max_towers];
    int mTowerCount;

    Enemy* mEnemies[max_enemies];
    int mEnemyCount;


    int mGold;
    int mLives;

    int mCurrentWave;
    float mSpawnTimer;      
    float mSpawnInterval;   
    int mEnemiesSpawned;  
    int mEnemiesPerWave;  
    bool mWaveInProgress;

    TowerType mSelectedType;

    Font mFont;
    bool mFontLoaded;

    void processEvents();
    void update(float deltaTime);
    void render();

    void spawnEnemy();
    void startNextWave();
    bool tryPlaceTower(float x, float y);
    void drawHUD();
    int towerCost(TowerType t) const;
    bool isOnPath(float x, float y) const;

    void drawWinScreen();
    void drawGameOverScreen();

    Music mMusic;
    SoundBuffer mWinBuffer;
    SoundBuffer mLoseBuffer;
    Sound mWinSound;
    Sound mLoseSound;
};