#include "BasicEnemy.h"
using namespace std;
using namespace sf;

BasicEnemy::BasicEnemy(float startX, float startY): Enemy(startX, startY, "BasicEnemy", 100, 100.0f, 10) {}

void BasicEnemy::move()
{
    move(0.016f);  
}

void BasicEnemy::move(float deltaTime)
{
    if (waypointCount == 0) return;

    if (waypointIndex >= waypointCount) {
        hasEscaped = true;
        isAlive = false;
        return;
    }

    float targetX = waypoints[waypointIndex].x;
    float targetY = waypoints[waypointIndex].y;

    moveToward(targetX, targetY, deltaTime);

    if (isAtWaypoint(targetX, targetY))
        waypointIndex++;
}

void BasicEnemy::takeDamage(int damage)
{
    Enemy::takeDamage(damage);
}

void BasicEnemy::render(RenderWindow& window)
{
    if (mTexture != nullptr) {
        mSprite.setPosition(x, y);
        window.draw(mSprite);
    }
    else {
        CircleShape shape(14.f);
        shape.setOrigin(14.f, 14.f);
        shape.setPosition(x, y);
        shape.setFillColor(Color(50, 180, 50));
        shape.setOutlineColor(Color(20, 120, 20));
        shape.setOutlineThickness(1.5f);
        window.draw(shape);
    }
    renderHpBar(window);
}

BasicEnemy::~BasicEnemy() {}