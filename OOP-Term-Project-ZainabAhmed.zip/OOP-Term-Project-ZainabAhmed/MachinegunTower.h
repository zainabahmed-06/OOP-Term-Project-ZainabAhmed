#pragma once
#include "Tower.h"

class MachineGunTower : public Tower {
public:
    MachineGunTower(float x, float y);

    void attack() override;
    void update(float deltaTime, Enemy** enemies, int count) override;
    void render(RenderWindow& window) override;
    void upgrade() override;

    ~MachineGunTower();
};