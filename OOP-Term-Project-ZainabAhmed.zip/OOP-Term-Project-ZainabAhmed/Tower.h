﻿#pragma once
#include <SFML/Graphics.hpp>
#include <string>
#include "Entity.h"
using namespace sf;

class Enemy;

static const int maxenemies_range = 32;

class Tower : public Entity {
protected:
    float range;          
    int   damage;         
    float fireRate;       
    float fireCooldown;  
    int   cost;          
    int   level;         

    Texture* mTexture;   
    Sprite   mSprite;

    Enemy* findTarget(Enemy** enemies, int count);

public:
    Tower(float x, float y, string name, float range, int damage, float fireRate, int cost);
    void setTexture(Texture& tex);
    float getRange() const;
    int   getDamage() const;
    float getFireRate() const;
    int   getCost() const;
    int   getLevel() const;

    virtual void upgrade();   

    void drawRange(RenderWindow& window);

    void move() override;   
    void takeDamage(int dmg) override;  

    virtual void attack() = 0;
    virtual void update(float deltaTime,
    Enemy** enemies, int count) = 0;
    virtual void render(RenderWindow& window) = 0;

    virtual ~Tower();
};