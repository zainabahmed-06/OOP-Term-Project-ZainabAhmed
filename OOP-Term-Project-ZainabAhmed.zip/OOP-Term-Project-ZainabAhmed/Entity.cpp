#include "Entity.h"
using namespace std;


Entity::Entity(float startX, float startY, string entityName): x(startX), y(startY), name(entityName), isAlive(true) {}

string Entity::getName() const { return name; }
bool Entity::getIsAlive() const { return isAlive; }
float Entity::getX() const { return x; }
float Entity::getY() const { return y; }

void Entity::setX(float newX) { x = newX; }
void Entity::setY(float newY) { y = newY; }
void Entity::setIsAlive(bool status) { isAlive = status; }

Entity::~Entity() {}

ostream& operator<<(ostream& os, const Entity& e) {
    os << e.name << " at (" << e.x << ", " << e.y << ") alive=" << e.isAlive;
    return os;
}