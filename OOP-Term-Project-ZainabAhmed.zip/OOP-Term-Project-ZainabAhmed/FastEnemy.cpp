#include "FastEnemy.h"
using namespace std;
using namespace sf;

FastEnemy::FastEnemy(float startX, float startY) : Enemy(startX, startY, "FastEnemy", 40, 220.0f, 15) {}

void FastEnemy::move()
{
    move(0.016f);
}

void FastEnemy::move(float deltaTime)
{
    if (waypointCount == 0) return;
    if (waypointIndex >= waypointCount) {
        hasEscaped = true;
        isAlive = false;
        return;
    }
    float targetX = waypoints[waypointIndex].x;
    float targetY = waypoints[waypointIndex].y;
    moveToward(targetX, targetY, deltaTime);
    if (isAtWaypoint(targetX, targetY))
        waypointIndex++;
}

void FastEnemy::takeDamage(int damage)
{
    Enemy::takeDamage(damage);
}

void FastEnemy::render(RenderWindow& window)
{
    if (mTexture != nullptr) {
        mSprite.setPosition(x, y);
        window.draw(mSprite);
    }
    else {
        CircleShape shape(10.f);
        shape.setOrigin(10.f, 10.f);
        shape.setPosition(x, y);
        shape.setFillColor(Color(240, 220, 30));
        shape.setOutlineColor(Color(180, 160, 10));
        shape.setOutlineThickness(1.5f);
        window.draw(shape);
    }
    renderHpBar(window);
}

FastEnemy::~FastEnemy() {}