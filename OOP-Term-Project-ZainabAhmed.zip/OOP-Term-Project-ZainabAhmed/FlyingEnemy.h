#pragma once
#include <SFML/Graphics.hpp>
#include "Enemy.h"

class FlyingEnemy : public Enemy {
private:
    float exitX;
    float exitY;

public:
    FlyingEnemy(float startX, float startY, float exitX, float exitY);

    void setExitPoint(float ex, float ey);
    void move() override;
    void move(float deltaTime) override;
    void takeDamage(int damage) override;
    void render(RenderWindow& window) override;

    ~FlyingEnemy();
};