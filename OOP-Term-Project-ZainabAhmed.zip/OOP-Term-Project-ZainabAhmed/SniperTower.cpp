#include "SniperTower.h"
#include "Enemy.h"
#include "Tower.h"
using namespace std;
using namespace sf;
SniperTower::SniperTower(float x, float y): Tower(x, y, "SniperTower", 220.f, 60, 0.4f, 150)
{}

void SniperTower::attack() {}   

void SniperTower::update(float deltaTime, Enemy** enemies, int count)
{
    if (fireCooldown > 0.f) {
        fireCooldown -= deltaTime;
        return;
    }

    Enemy* target = findTarget(enemies, count);
    if (target == nullptr) return;

    target->takeDamage(damage);
    fireCooldown = 1.f / fireRate;
}

void SniperTower::render(RenderWindow& window)
{
    drawRange(window);
    if (mTexture != nullptr) {
        mSprite.setPosition(x, y);
        window.draw(mSprite);
    }
    else {
        CircleShape base(16.f);
        base.setOrigin(16.f, 16.f);
        base.setPosition(x, y);
        base.setFillColor(Color(30, 80, 40));
        base.setOutlineColor(Color(10, 50, 20));
        base.setOutlineThickness(2.f);
        window.draw(base);

        RectangleShape barrel(Vector2f(38.f, 5.f));
        barrel.setOrigin(0.f, 2.5f);
        barrel.setPosition(x, y);
        barrel.setFillColor(Color(20, 60, 30));
        window.draw(barrel);
    }
}

void SniperTower::upgrade()
{
    Tower::upgrade();
    range += 40.f;
}

SniperTower::~SniperTower() {}