#pragma once
#include "Tower.h"

class CannonTower : public Tower {
public:
    CannonTower(float x, float y);

    void attack() override;
    void update(float deltaTime, Enemy** enemies, int count) override;
    void render(RenderWindow& window) override;
    void upgrade() override;

    ~CannonTower();
};