﻿#include "Enemy.h"
#include <cmath>
using namespace std;
using namespace sf;


Enemy::Enemy(float startX, float startY, string name, int hp, float speed, int goldReward): Entity(startX, startY, name),
    hp(hp), maxHp(hp),
    speed(speed), speedMultiplier(1.0f),
    goldReward(goldReward),
    waypointIndex(0),
    hasEscaped(false),
    slowTimer(0.f),
    isPoisoned(false), poisonTimer(0.f), poisonDamagePerSec(0),
    waypointCount(0),
    mTexture(nullptr) {}

void Enemy::setWaypoints(const Waypoint* pts, int count)
{
    if (count < max_enemywaypoints)
        waypointCount = count;
    else
        waypointCount = max_enemywaypoints;

    for (int i = 0; i < waypointCount; ++i)
        waypoints[i] = pts[i];
}

bool Enemy::isAtWaypoint(float targetX, float targetY) const
{
    float dx = x - targetX;
    float dy = y - targetY;
    return (dx * dx + dy * dy) < (5.f * 5.f);  
}

void Enemy::moveToward(float targetX, float targetY, float deltaTime)
{
    float dx = targetX - x;
    float dy = targetY - y;
    float dist = sqrt(dx * dx + dy * dy);
    if (dist < 1.f) return;

    float effectiveSpeed = speed * speedMultiplier;
    float step = effectiveSpeed * deltaTime;
    if (step > dist) step = dist;

    x += (dx / dist) * step;
    y += (dy / dist) * step;
}

void Enemy::setSize(float targetSize) {
    if (!mTexture) return;
    Vector2u s = mTexture->getSize();
    float scaleX = targetSize / static_cast<float>(s.x);
    float scaleY = targetSize / static_cast<float>(s.y);
    mSprite.setScale(scaleX, scaleY);
}

void Enemy::setTexture(Texture& tex, float targetSize)
{
    mTexture = &tex;
    mSprite.setTexture(tex);
    Vector2u s = tex.getSize();
    mSprite.setOrigin(s.x / 2.f, s.y / 2.f);

    float scaleX = targetSize / static_cast<float>(s.x);
    float scaleY = targetSize / static_cast<float>(s.y);
    mSprite.setScale(scaleX, scaleY);
}

int   Enemy::getHp() const { return hp; }
int   Enemy::getMaxHp() const { return maxHp; }
float Enemy::getSpeed() const { return speed; }
int   Enemy::getGoldReward() const { return goldReward; }
int   Enemy::getWaypointIndex() const { return waypointIndex; }
bool  Enemy::getHasEscaped() const { return hasEscaped; }
void  Enemy::setHasEscaped(bool status) { hasEscaped = status; }


void Enemy::applySlow(float multiplier, float duration)
{
    speedMultiplier = multiplier;
    slowTimer = duration;
}

void Enemy::applyPoison(float duration, int dmgPerSec)
{
    isPoisoned = true;
    poisonTimer = duration;
    poisonDamagePerSec = dmgPerSec;
}

void Enemy::updateStatusEffects(float deltaTime)
{
    if (slowTimer > 0.f) {
        slowTimer -= deltaTime;
        if (slowTimer <= 0.f) {
            slowTimer = 0.f;
            speedMultiplier = 1.0f;
        }
    }

    if (isPoisoned) {
        poisonTimer -= deltaTime;
        takeDamage(static_cast<int>(poisonDamagePerSec * deltaTime));
        if (poisonTimer <= 0.f) {
            isPoisoned = false;
            poisonTimer = 0.f;
        }
    }
}

void Enemy::takeDamage(int damage)
{
    hp -= damage;
    if (hp <= 0) {
        hp = 0;
        isAlive = false;
    }
}

void Enemy::attack() {}

void Enemy::renderHpBar(RenderWindow& window)
{
    const float barW = 30.f;
    const float barH = 5.f;
    const float above = 18.f;

    float ratio = static_cast<float>(hp) / static_cast<float>(maxHp);

    RectangleShape bg(Vector2f(barW, barH));
    bg.setFillColor(Color(180, 0, 0));
    bg.setPosition(x - barW / 2.f, y - above);
    window.draw(bg);

    RectangleShape fg(Vector2f(barW * ratio, barH));
    fg.setFillColor(Color(0, 200, 0));
    fg.setPosition(x - barW / 2.f, y - above);
    window.draw(fg);
}

Enemy::~Enemy() {}