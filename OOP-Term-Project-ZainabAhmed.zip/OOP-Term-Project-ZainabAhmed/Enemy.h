﻿#pragma once
#include <SFML/Graphics.hpp>
#include <string>
#include "Entity.h"
using namespace sf;
using namespace std;

class Waypoint {
public:
    float x;
    float y;
};

static const int max_enemywaypoints = 8;

class Enemy : public Entity {

protected:
    int   hp;
    int   maxHp;
    float speed;
    float speedMultiplier;
    int   goldReward;
    int   waypointIndex;
    bool  hasEscaped;

    float slowTimer;
    bool  isPoisoned;
    float poisonTimer;
    int   poisonDamagePerSec;

    Waypoint waypoints[max_enemywaypoints];
    int      waypointCount;

    Texture* mTexture;  
    Sprite   mSprite;

public:
    Enemy(float startX, float startY, string name, int hp, float speed, int goldReward);

    void setWaypoints(const Waypoint* pts, int count);
    bool isAtWaypoint(float targetX, float targetY) const;
    void moveToward(float targetX, float targetY, float deltaTime);

    void setTexture(Texture& tex, float targetSize = 40.f);
    void setSize(float targetSize);

    int   getHp() const;
    int   getMaxHp() const;
    float getSpeed() const;
    int   getGoldReward() const;
    int   getWaypointIndex() const;
    bool  getHasEscaped() const;

    void setHasEscaped(bool status);

    void applySlow(float multiplier, float duration);
    void applyPoison(float duration, int dmgPerSec);
    void updateStatusEffects(float deltaTime);

    void renderHpBar(RenderWindow& window);

    void attack() override;
    void takeDamage(int damage) override;

    virtual void move() = 0;
    virtual void move(float deltaTime) = 0;
    virtual void render(RenderWindow& window) = 0;

    virtual ~Enemy();
};