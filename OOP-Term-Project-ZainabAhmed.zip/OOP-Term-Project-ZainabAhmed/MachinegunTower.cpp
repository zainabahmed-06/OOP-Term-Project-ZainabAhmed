#include "MachineGunTower.h"
#include "Enemy.h"
#include "Tower.h"
using namespace std;
using namespace sf;

MachineGunTower::MachineGunTower(float x, float y): Tower(x, y, "MachineGunTower", 110.f, 12, 4.0f, 175) {}

void MachineGunTower::attack() {}   

void MachineGunTower::update(float deltaTime, Enemy** enemies, int count)
{
    if (fireCooldown > 0.f) {
        fireCooldown -= deltaTime;
        return;
    }

    Enemy* target = findTarget(enemies, count);
    if (target == nullptr) return;

    target->takeDamage(damage);
    fireCooldown = 1.f / fireRate;
}

void MachineGunTower::render(RenderWindow& window)
{
    drawRange(window);
    if (mTexture != nullptr) {
        mSprite.setPosition(x, y);
        window.draw(mSprite);
    }
    else {
        CircleShape base(18.f);
        base.setOrigin(18.f, 18.f);
        base.setPosition(x, y);
        base.setFillColor(Color(180, 90, 20));
        base.setOutlineColor(Color(120, 60, 10));
        base.setOutlineThickness(2.f);
        window.draw(base);

        RectangleShape barrel1(Vector2f(22.f, 5.f));
        barrel1.setOrigin(0.f, 6.f);
        barrel1.setPosition(x, y);
        barrel1.setFillColor(Color(120, 60, 10));
        window.draw(barrel1);

        RectangleShape barrel2(Vector2f(22.f, 5.f));
        barrel2.setOrigin(0.f, -1.f);
        barrel2.setPosition(x, y);
        barrel2.setFillColor(Color(120, 60, 10));
        window.draw(barrel2);
    }
}

void MachineGunTower::upgrade()
{
    Tower::upgrade();
    fireRate += 1.5f;
}

MachineGunTower::~MachineGunTower() {}