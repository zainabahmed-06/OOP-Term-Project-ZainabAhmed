﻿#include "Tower.h"
#include "Enemy.h"
#include <cmath>
using namespace std;
using namespace sf;

Tower::Tower(float x, float y, string name, float range, int damage, float fireRate, int cost): Entity(x, y, name),
    range(range),
    damage(damage),
    fireRate(fireRate),
    fireCooldown(0.f),
    cost(cost),
    level(1),
    mTexture(nullptr) {}

void Tower::setTexture(Texture& tex)
{
    mTexture = &tex;
    mSprite.setTexture(tex);
    Vector2u s = tex.getSize();
    mSprite.setOrigin(s.x / 2.f, s.y / 2.f);
    float targetSize = 55.f;  
    float scaleX = targetSize / static_cast<float>(s.x);
    float scaleY = targetSize / static_cast<float>(s.y);
    mSprite.setScale(scaleX, scaleY);
}

float Tower::getRange() const { return range; }
int Tower::getDamage() const { return damage; }
float Tower::getFireRate() const { return fireRate; }
int Tower::getCost() const { return cost; }
int Tower::getLevel() const { return level; }

void Tower::upgrade()
{
    level++;
    damage = static_cast<int>(damage * 1.3f);
    range *= 1.15f;
}

void Tower::drawRange(RenderWindow& window)
{
    CircleShape circle(range);
    circle.setOrigin(range, range);
    circle.setPosition(x, y);
    circle.setFillColor(Color(255, 255, 255, 30));
    circle.setOutlineColor(Color(255, 255, 255, 120));
    circle.setOutlineThickness(1.f);
    window.draw(circle);
}

Enemy* Tower::findTarget(Enemy** enemies, int count)
{
    for (int i = 0; i < count; ++i) {
        if (enemies[i] == nullptr) continue;
        if (!enemies[i]->getIsAlive()) continue;

        float dx = enemies[i]->getX() - x;
        float dy = enemies[i]->getY() - y;
        float dist = sqrt(dx * dx + dy * dy);

        if (dist <= range) {
            return enemies[i];
        }
    }
    return nullptr;
}

void Tower::move() {}
void Tower::takeDamage(int) {}

Tower::~Tower() {}