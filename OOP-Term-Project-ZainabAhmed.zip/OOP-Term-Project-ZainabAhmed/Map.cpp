﻿#include "Map.h"
#include <iostream>
#include <cmath>
using namespace sf;
using namespace std;


static const float p_width = 75.f;
static const Color p_color(101, 67, 33, 225);   



Map::Map(unsigned int windowWidth, unsigned int windowHeight ):
    mWidth(windowWidth),
    mHeight(windowHeight),
    mBackgroundLoaded(false),
    mWaypointCount(0),
    mSegmentCount(0),
    mEnemyTextureCount(0),
    mTowerTextureCount(0)
{
    for (int i = 0; i < max_enemytypes; ++i) {
        mEnemyTextures[i].name[0] = '\0';
        mEnemyTextures[i].texture = nullptr;
    }

    for (int i = 0; i < max_towertypes; ++i) {
        mTowerTextures[i].name[0] = '\0';
        mTowerTextures[i].texture = nullptr;
    }

    buildPath();
    buildPathVisuals();
}

Map::~Map()
{
    for (int i = 0; i < mEnemyTextureCount; ++i) {
        delete mEnemyTextures[i].texture;
        mEnemyTextures[i].texture = nullptr;
    }
    for (int i = 0; i < mTowerTextureCount; ++i) {
        delete mTowerTextures[i].texture;
        mTowerTextures[i].texture = nullptr;
    }
}

bool Map::loadBackground(const string& filePath)
{
    if (!mBackgroundTexture.loadFromFile(filePath)) {
        cout << "[Map] Failed to load background: " << filePath << "\n";
        mBackgroundLoaded = false;
        return false;
    }

    mBackgroundSprite.setTexture(mBackgroundTexture);

    Vector2u texSize = mBackgroundTexture.getSize();
    float scaleX = static_cast<float>(mWidth) / static_cast<float>(texSize.x);
    float scaleY = static_cast<float>(mHeight) / static_cast<float>(texSize.y);
    mBackgroundSprite.setScale(scaleX, scaleY);

    mBackgroundLoaded = true;
    return true;
}


bool Map::loadEnemyTexture(const string& enemyName, const string& filePath)
{
    for (int i = 0; i < mEnemyTextureCount; ++i) {
        if (strcmp(mEnemyTextures[i].name, enemyName.c_str()) == 0) {
            delete mEnemyTextures[i].texture;
            mEnemyTextures[i].texture = new Texture();
            if (!mEnemyTextures[i].texture->loadFromFile(filePath)) {
                cout << "[Map] Failed to reload texture '" << enemyName << "'\n";
                delete mEnemyTextures[i].texture;
                mEnemyTextures[i].texture = nullptr;
                return false;
            }
            return true;
        }
    }

    if (mEnemyTextureCount >= max_enemytypes) {
        cout << "[Map] Enemy texture table full, cannot load: " << enemyName << "\n";
        return false;
    }

    Texture* tex = new Texture();
    if (!tex->loadFromFile(filePath)) {
        cout << "[Map] Failed to load texture '" << enemyName<< "' from: " << filePath << "\n";
        delete tex;
        return false;
    }

    const char* src = enemyName.c_str();
    int i = 0;
    while (i < 31 && src[i] != '\0') {
        mEnemyTextures[mEnemyTextureCount].name[i] = src[i];
        i++;
    }
    mEnemyTextures[mEnemyTextureCount].name[i] = '\0';
    mEnemyTextures[mEnemyTextureCount].texture = tex;
    ++mEnemyTextureCount;

    cout << "[Map] Loaded enemy texture: " << enemyName << "\n";
    return true;
}

Texture* Map::getEnemyTexture(const string& enemyName)
{
    for (int i = 0; i < mEnemyTextureCount; ++i) {
        if (strcmp(mEnemyTextures[i].name, enemyName.c_str()) == 0) {
            return mEnemyTextures[i].texture;
        }
    }
    cout << "[Map] Texture not found for enemy: " << enemyName << "\n";
    return nullptr;
}

bool Map::loadTowerTexture(const string& towerName, const string& filePath)
{
    for (int i = 0; i < mTowerTextureCount; ++i) {
        if (towerName == mTowerTextures[i].name) {
            delete mTowerTextures[i].texture;
            mTowerTextures[i].texture = new Texture();
            if (!mTowerTextures[i].texture->loadFromFile(filePath)) {
                delete mTowerTextures[i].texture;
                mTowerTextures[i].texture = nullptr;
                return false;
            }
            return true;
        }
    }

    if (mTowerTextureCount >= max_towertypes) return false;

    Texture* tex = new Texture();
    if (!tex->loadFromFile(filePath)) { delete tex; return false; }

    const char* src = towerName.c_str();
    int i = 0;
    while (i < 31 && src[i] != '\0') {
        mTowerTextures[mTowerTextureCount].name[i] = src[i];
        i++;
    }
    mTowerTextures[mTowerTextureCount].name[i] = '\0';
    mTowerTextures[mTowerTextureCount].texture = tex;
    ++mTowerTextureCount;
    return true;
}

Texture* Map::getTowerTexture(const string& towerName)
{
    for (int i = 0; i < mTowerTextureCount; ++i) {
        if (towerName == mTowerTextures[i].name)
            return mTowerTextures[i].texture;
    }
    return nullptr;
}

static const float MAP_W = 1024.f;

void Map::buildPath()
{
    float W = MAP_W;
    float H = static_cast<float>(mHeight);

    mWaypointCount = 0;

    mPathWaypoints[mWaypointCount++] = Vector2f(0.f, H * 0.12f);  
    mPathWaypoints[mWaypointCount++] = Vector2f(W * 0.88f, H * 0.12f);  
    mPathWaypoints[mWaypointCount++] = Vector2f(W * 0.88f, H * 0.38f); 
    mPathWaypoints[mWaypointCount++] = Vector2f(W * 0.12f, H * 0.38f);
    mPathWaypoints[mWaypointCount++] = Vector2f(W * 0.12f, H * 0.62f); 
    mPathWaypoints[mWaypointCount++] = Vector2f(W * 0.88f, H * 0.62f); 
    mPathWaypoints[mWaypointCount++] = Vector2f(W * 0.88f, H * 0.88f); 
    mPathWaypoints[mWaypointCount++] = Vector2f(W, H * 0.88f); 
}


void Map::buildPathVisuals()
{
    mSegmentCount = 0;

    for (int i = 0; i + 1 < mWaypointCount; ++i) {
        Vector2f from = mPathWaypoints[i];
        Vector2f to = mPathWaypoints[i + 1];

        Vector2f delta = to - from;
        float length = sqrt(delta.x * delta.x + delta.y * delta.y);
        float angle = atan2(delta.y, delta.x) * 180.f / 3.14159265f;

        mPathSegments[mSegmentCount].setSize(Vector2f(length, p_width));
        mPathSegments[mSegmentCount].setOrigin(0.f, p_width / 2.f);
        mPathSegments[mSegmentCount].setPosition(from);
        mPathSegments[mSegmentCount].setRotation(angle);
        mPathSegments[mSegmentCount].setFillColor(p_color);
        ++mSegmentCount;
    }

    for (int i = 1; i + 1 < mWaypointCount; ++i) {
        mPathSegments[mSegmentCount].setSize(Vector2f(p_width, p_width));
        mPathSegments[mSegmentCount].setOrigin(p_width / 2.f, p_width / 2.f);
        mPathSegments[mSegmentCount].setPosition(mPathWaypoints[i]);
        mPathSegments[mSegmentCount].setRotation(0.f);
        mPathSegments[mSegmentCount].setFillColor(p_color);
        ++mSegmentCount;
    }
}

void Map::draw(RenderWindow& window)
{
    if (mBackgroundLoaded) {
        window.draw(mBackgroundSprite);
    }
    else {
        RectangleShape bg(Vector2f(static_cast<float>(mWidth),
            static_cast<float>(mHeight)));
        bg.setFillColor(Color(34, 139, 34));
        window.draw(bg);
    }

    for (int i = 0; i < mSegmentCount; ++i) {
        window.draw(mPathSegments[i]);
    }
}

const Vector2f* Map::getPath() const
{
    return mPathWaypoints;
}

int Map::getPathSize() const
{
    return mWaypointCount;
}

Vector2f Map::getStartPosition() const
{
    if (mWaypointCount == 0) return Vector2f(0.f, 0.f);
    return mPathWaypoints[0];
}

Vector2f Map::getExitPosition() const
{
    if (mWaypointCount == 0) return Vector2f(0.f, 0.f);
    return mPathWaypoints[mWaypointCount - 1];
}