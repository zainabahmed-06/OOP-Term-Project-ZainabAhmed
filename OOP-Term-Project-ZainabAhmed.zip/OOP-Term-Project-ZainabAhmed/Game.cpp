﻿#include "Game.h"
#include <iostream>
#include <cmath>
using namespace sf;
using namespace std;

static const unsigned int width = 1224;
static const unsigned int height = 768;


Game::Game(): mWindow(VideoMode(width, height), "Tower Defense"),
    mMap(width, height),
    mTowerCount(0),
    mEnemyCount(0),
    mGold(500),
    mLives(10),
    mCurrentWave(0),
    mSpawnTimer(0.f),
    mSpawnInterval(1.5f),
    mEnemiesSpawned(0),
    mEnemiesPerWave(5),
    mWaveInProgress(false),
    mSelectedType(TowerType::Cannon),
    mFontLoaded(false),
    mGameWon(false),
    mGameOver(false)
{
    mWindow.setFramerateLimit(60);

    for (int i = 0; i < max_towers; ++i) mTowers[i] = nullptr;
    for (int i = 0; i < max_enemies; ++i) mEnemies[i] = nullptr;

    mMap.loadBackground("background.png");
    mMap.loadEnemyTexture("BasicEnemy", "basicenemy.png");
    mMap.loadEnemyTexture("FastEnemy", "fastenemy.png");
    mMap.loadEnemyTexture("TankEnemy", "tankenemy.png");
    mMap.loadEnemyTexture("FlyingEnemy", "flyingenemy.png");
    mMap.loadTowerTexture("CannonTower", "cannontower.png");
    mMap.loadTowerTexture("SniperTower", "snipertower.png");
    mMap.loadTowerTexture("MachineGunTower", "machineguntower.png");
    mMap.loadTowerTexture("SlowTower", "slowtower.png");

    if (mFont.loadFromFile("Roboto-Regular.ttf")) mFontLoaded = true;

    mWaveData[0] = { 4, 0, 0, 0 };
    mWaveData[1] = { 4, 2, 2, 0 };
    mWaveData[2] = { 4, 3, 3, 2 };
    mWaveData[3] = { 4, 4, 4, 4 };
    mWaveData[4] = { 5, 5, 5, 5 };

    if (mMusic.openFromFile("backgroundmusic.ogg")) {
        mMusic.setLoop(true);     
        mMusic.setVolume(100.f);   
        mMusic.play();
    }

    if (mWinBuffer.loadFromFile("wingame.ogg")) mWinSound.setBuffer(mWinBuffer);

    if (mLoseBuffer.loadFromFile("lostgame.ogg")) mLoseSound.setBuffer(mLoseBuffer);

    startNextWave();
    buildSidebar();

}

void Game::buildSidebar()
{
    TowerType types[cards] = { TowerType::Cannon, TowerType::Sniper, TowerType::MachineGun, TowerType::Slow };
    const char* names[cards] = { "Cannon", "Sniper", "MachineGun", "Slow" };
    int costs[cards] = { 125, 150, 175, 100 };
    const char* texKeys[cards] = { "CannonTower", "SniperTower", "MachineGunTower", "SlowTower" };

    for (int i = 0; i < cards; ++i) {
        mCards[i].type = types[i];
        mCards[i].name = names[i];
        mCards[i].cost = costs[i];

        mCards[i].cardBg.setSize(Vector2f(160.f, 120.f));
        mCards[i].cardBg.setPosition(1034.f, 45.f + i * 135.f);
        mCards[i].cardBg.setFillColor(Color(40, 40, 60));
        mCards[i].cardBg.setOutlineColor(Color(100, 100, 150));
        mCards[i].cardBg.setOutlineThickness(2.f);

        Texture* tex = mMap.getTowerTexture(texKeys[i]);
        if (tex) {
            mCards[i].icon.setTexture(*tex);
            Vector2u s = tex->getSize();
            float scale = 48.f / static_cast<float>(max(s.x, s.y));
            mCards[i].icon.setScale(scale, scale);
            mCards[i].icon.setPosition(1034.f + (160.f - 48.f) / 2.f, 45.f + i * 135.f + 10.f);
        }
    }

    mDragging = false;
    mDragType = TowerType::None;
    mSelectedType = TowerType::None;
}


Game::~Game()
{
    for (int i = 0; i < max_towers; ++i) { delete mTowers[i];  mTowers[i] = nullptr; }
    for (int i = 0; i < max_enemies; ++i) { delete mEnemies[i]; mEnemies[i] = nullptr; }
}


void Game::run()
{
    Clock clock;

    while (mWindow.isOpen()) {
        float deltaTime = clock.restart().asSeconds();
        if (deltaTime > 0.05f) deltaTime = 0.05f;   

        processEvents();
        update(deltaTime);
        render();
    }
}


void Game::processEvents()
{
    Event event;
    while (mWindow.pollEvent(event)) {

        if (event.type == Event::Closed)
            mWindow.close();

        if (event.type == Event::MouseButtonPressed &&
            event.mouseButton.button == Mouse::Left)
        {
            float mx = static_cast<float>(event.mouseButton.x);
            float my = static_cast<float>(event.mouseButton.y);

            for (int i = 0; i < cards; ++i) {
                if (mCards[i].cardBg.getGlobalBounds().contains(mx, my)) {
                    mDragging = true;
                    mDragType = mCards[i].type;
                    mDragSprite = mCards[i].icon;
                    mDragSprite.setOrigin(24.f, 24.f);
                    break;
                }
            }
        }

        if (event.type == Event::MouseButtonReleased &&
            event.mouseButton.button == Mouse::Left)
        {
            float mx = static_cast<float>(event.mouseButton.x);
            float my = static_cast<float>(event.mouseButton.y);

            if (mDragging && mx < 1024.f) {
                mSelectedType = mDragType;
                tryPlaceTower(mx, my);
                mSelectedType = TowerType::None;
            }
            mDragging = false;
            mDragType = TowerType::None;
        }

    } 

    if (mDragging) {
        Vector2i mp = Mouse::getPosition(mWindow);
        mDragSprite.setPosition(static_cast<float>(mp.x),
            static_cast<float>(mp.y));
    }
}


void Game::drawSidebar()
{
    RectangleShape bg(Vector2f(200.f, 768.f));
    bg.setPosition(1024.f, 0.f);
    bg.setFillColor(Color(25, 25, 40));
    mWindow.draw(bg);

    RectangleShape divider(Vector2f(2.f, 768.f));
    divider.setPosition(1024.f, 0.f);
    divider.setFillColor(Color(100, 100, 150));
    mWindow.draw(divider);

    if (mFontLoaded) {
        Text heading;
        heading.setFont(mFont);
        heading.setString("Towers Shop");
        heading.setCharacterSize(18);
        heading.setFillColor(Color(220, 200, 255));
        heading.setStyle(Text::Bold);

        FloatRect hb = heading.getLocalBounds();
        heading.setOrigin(hb.width / 2.f, 0.f);
        heading.setPosition(1024.f + 100.f, 8.f); 
        mWindow.draw(heading);
    }

    for (int i = 0; i < cards; ++i) {
        if (mDragging && mDragType == mCards[i].type)
            mCards[i].cardBg.setFillColor(Color(70, 70, 100));
        else
            mCards[i].cardBg.setFillColor(Color(40, 40, 60));

        mWindow.draw(mCards[i].cardBg);
        mWindow.draw(mCards[i].icon);

        if (!mFontLoaded) continue;

        Text nameText;
        nameText.setFont(mFont);
        nameText.setCharacterSize(14);
        nameText.setFillColor(Color::White);
        nameText.setString(mCards[i].name);
        nameText.setPosition(1040.f, 45.f + i * 135.f + 68.f);
        mWindow.draw(nameText);

        Text costText;
        costText.setFont(mFont);
        costText.setCharacterSize(13);
        costText.setFillColor(Color(220, 180, 0));
        costText.setString("$" + to_string(mCards[i].cost));
        costText.setPosition(1040.f, 45.f + i * 135.f + 90.f);

        if (mGold < mCards[i].cost)
            costText.setFillColor(Color(150, 80, 80));

        mWindow.draw(costText);
    }

    if (mDragging)
        mWindow.draw(mDragSprite);
}


void Game::update(float deltaTime)
{
    if (mGameWon || mGameOver) return;
    if (mWaveInProgress && mEnemiesSpawned < mEnemiesPerWave) {
        mSpawnTimer -= deltaTime;
        if (mSpawnTimer <= 0.f) {
            spawnEnemy();
            mSpawnTimer = mSpawnInterval;
        }
    }

    for (int i = 0; i < max_enemies; ++i) {
        if (mEnemies[i] == nullptr) continue;

        mEnemies[i]->updateStatusEffects(deltaTime);
        mEnemies[i]->move(deltaTime);

        if (mEnemies[i]->getHasEscaped()) {
            mLives--;
            cout << "Life lost! Lives remaining: " << mLives << "\n";
            delete mEnemies[i];
            mEnemies[i] = nullptr;
            mEnemyCount--;
            continue;
        }

        if (!mEnemies[i]->getIsAlive()) {
            mGold += mEnemies[i]->getGoldReward();
            cout << "Enemy killed! Gold: " << mGold << "\n";
            delete mEnemies[i];
            mEnemies[i] = nullptr;
            mEnemyCount--;
        }
    }

    for (int i = 0; i < max_towers; ++i) {
        if (mTowers[i] == nullptr) continue;
        mTowers[i]->update(deltaTime, mEnemies, max_enemies);
    }

    if (mWaveInProgress && mEnemiesSpawned >= mEnemiesPerWave && mEnemyCount == 0)
    {
        mWaveInProgress = false;
        cout << "Wave " << mCurrentWave << " complete!\n";

        if (mCurrentWave >= max_waves) {
            mGameWon = true;
            mMusic.stop();
            mWinSound.play();
        }
        else {
            startNextWave();
        }
    }

    if (mLives <= 0) {
        mGameOver = true;
        mMusic.stop();
        mLoseSound.play();
    }
}


void Game::drawWinScreen()
{
    RectangleShape overlay(Vector2f(1024.f, 768.f));
    overlay.setFillColor(Color(0, 80, 0, 200));
    mWindow.draw(overlay);

    RectangleShape box(Vector2f(500.f, 250.f));
    box.setOrigin(250.f, 125.f);
    box.setPosition(512.f, 384.f);
    box.setFillColor(Color(255, 255, 255, 240));
    box.setOutlineColor(Color(0, 150, 0));
    box.setOutlineThickness(4.f);
    mWindow.draw(box);

    if (!mFontLoaded) return;

    Text title;
    title.setFont(mFont);
    title.setString("YOU WIN!");
    title.setCharacterSize(60);
    title.setFillColor(Color(0, 150, 0));
    title.setStyle(Text::Bold);
    FloatRect tb = title.getLocalBounds();
    title.setOrigin(tb.width / 2.f, tb.height / 2.f);
    title.setPosition(512.f, 330.f);
    mWindow.draw(title);

    Text sub;
    sub.setFont(mFont);
    sub.setString("All waves defeated!\nPress ESC to exit.");
    sub.setCharacterSize(24);
    sub.setFillColor(Color(40, 40, 40));
    FloatRect sb = sub.getLocalBounds();
    sub.setOrigin(sb.width / 2.f, 0.f);
    sub.setPosition(512.f, 410.f);
    mWindow.draw(sub);
}

void Game::drawGameOverScreen()
{
    RectangleShape overlay(Vector2f(1024.f, 768.f));
    overlay.setFillColor(Color(80, 0, 0, 200));
    mWindow.draw(overlay);

    RectangleShape box(Vector2f(500.f, 250.f));
    box.setOrigin(250.f, 125.f);
    box.setPosition(512.f, 384.f);
    box.setFillColor(Color(255, 255, 255, 240));
    box.setOutlineColor(Color(180, 0, 0));
    box.setOutlineThickness(4.f);
    mWindow.draw(box);

    if (!mFontLoaded) return;

    Text title;
    title.setFont(mFont);
    title.setString("GAME OVER");
    title.setCharacterSize(60);
    title.setFillColor(Color(180, 0, 0));
    title.setStyle(Text::Bold);
    FloatRect tb = title.getLocalBounds();
    title.setOrigin(tb.width / 2.f, tb.height / 2.f);
    title.setPosition(512.f, 330.f);
    mWindow.draw(title);

    Text sub;
    sub.setFont(mFont);
    sub.setString("All lives lost!\nPress ESC to exit.");
    sub.setCharacterSize(24);
    sub.setFillColor(Color(40, 40, 40));
    FloatRect sb = sub.getLocalBounds();
    sub.setOrigin(sb.width / 2.f, 0.f);
    sub.setPosition(512.f, 410.f);
    mWindow.draw(sub);
}



void Game::render()
{
    mWindow.clear();

    mMap.draw(mWindow);

    for (int i = 0; i < max_towers; ++i) {
        if (mTowers[i] == nullptr) continue;
        mTowers[i]->render(mWindow);
    }

    for (int i = 0; i < max_enemies; ++i) {
        if (mEnemies[i] == nullptr) continue;
        mEnemies[i]->render(mWindow);
    }

    drawHUD();
    drawSidebar();

    if (mGameWon)  drawWinScreen();
    if (mGameOver) drawGameOverScreen();

    mWindow.display();
}


void Game::spawnEnemy()
{
    if (mEnemyCount >= max_enemies) return;

    int slot = -1;
    for (int i = 0; i < max_enemies; ++i) {
        if (mEnemies[i] == nullptr) { slot = i; break; }
    }
    if (slot == -1) return;

    Vector2f start = mMap.getStartPosition();
    Vector2f exit = mMap.getExitPosition();

    const Vector2f* mapPath = mMap.getPath();
    int pathSize = mMap.getPathSize();

    Waypoint wpts[max_enemywaypoints];
    int wCount;
    if (pathSize < max_enemywaypoints)
        wCount = pathSize;
    else
        wCount = max_enemywaypoints;

    for (int i = 0; i < wCount; ++i) {
        wpts[i].x = mapPath[i].x;
        wpts[i].y = mapPath[i].y;
    }

    Enemy* e = nullptr;

    if (mBasicLeft > 0) {
        BasicEnemy* be = new BasicEnemy(start.x, start.y);
        be->setWaypoints(wpts, wCount);
        Texture* t = mMap.getEnemyTexture("BasicEnemy");
        if (t) be->setTexture(*t);
        e = be;
        mBasicLeft--;
    }
    else if (mFastLeft > 0) {
        FastEnemy* fe = new FastEnemy(start.x, start.y);
        fe->setWaypoints(wpts, wCount);
        Texture* t = mMap.getEnemyTexture("FastEnemy");
        if (t) fe->setTexture(*t);
        e = fe;
        mFastLeft--;
    }
    else if (mFlyingLeft > 0) {
        FlyingEnemy* fly = new FlyingEnemy(start.x, start.y, exit.x, exit.y);
        Texture* t = mMap.getEnemyTexture("FlyingEnemy");
        if (t) fly->setTexture(*t, 75.f);
        e = fly;
        mFlyingLeft--;
    }
    else if (mTankLeft > 0) {
        TankEnemy* te = new TankEnemy(start.x, start.y);
        te->setWaypoints(wpts, wCount);
        Texture* t = mMap.getEnemyTexture("TankEnemy");
        if (t) te->setTexture(*t,100.f);
        e = te;
        mTankLeft--;
    }
    if (e != nullptr) {
        mEnemies[slot] = e;
        mEnemyCount++;
        mEnemiesSpawned++;
    }
}

void Game::startNextWave()
{
    mCurrentWave++;
    mEnemiesSpawned = 0;
    mEnemiesPerWave = 5 + (mCurrentWave - 1) * 3;   
    mSpawnInterval = 1.5f - (mCurrentWave * 0.05f); 
    if (mSpawnInterval < 0.5f) mSpawnInterval = 0.5f;
    mSpawnTimer = 0.f;
    mWaveInProgress = true;

    int idx = mCurrentWave - 1; 
    mBasicLeft = mWaveData[idx].basicCount;
    mFastLeft = mWaveData[idx].fastCount;
    mFlyingLeft = mWaveData[idx].flyingCount;
    mTankLeft = mWaveData[idx].tankCount;

    mEnemiesPerWave = mBasicLeft + mFastLeft + mFlyingLeft + mTankLeft;
    cout << "Wave " << mCurrentWave << " starting! Enemies: " << mEnemiesPerWave << "\n";
}

bool Game::tryPlaceTower(float mx, float my)
{
    if (mTowerCount >= max_towers) return false;

    if (isOnPath(mx, my)) {
        cout << "Cannot place tower on path!\n";
        return false;
    }
    int cost = towerCost(mSelectedType);
    if (mGold < cost) {
        cout << "Not enough gold! Need " << cost << ", have " << mGold << "\n";
        return false;
    }

    int slot = -1;
    for (int i = 0; i < max_towers; ++i) {
        if (mTowers[i] == nullptr) { slot = i; break; }
    }
    if (slot == -1) return false;

    Tower* t = nullptr;
    switch (mSelectedType) {
    case TowerType::Cannon: t = new CannonTower(mx, my); break;
    case TowerType::Sniper: t = new SniperTower(mx, my); break;
    case TowerType::MachineGun: t = new MachineGunTower(mx, my); break;
    case TowerType::Slow: t = new SlowTower(mx, my); break;
    default: return false;
    }

    mTowers[slot] = t;
    mTowerCount++;
    mGold -= cost;

    const char* texName = "";
    switch (mSelectedType) {
    case TowerType::Cannon: texName = "CannonTower"; break;
    case TowerType::Sniper: texName = "SniperTower"; break;
    case TowerType::MachineGun: texName = "MachineGunTower"; break;
    case TowerType::Slow: texName = "SlowTower"; break;
    default: break;
    }
    Texture* tex = mMap.getTowerTexture(texName);
    if (tex) mTowers[slot]->setTexture(*tex);
    cout << "Tower placed! Gold remaining: " << mGold << "\n";
    return true;
}

bool Game::isOnPath(float mx, float my) const
{
    const Vector2f* path = mMap.getPath();
    int size = mMap.getPathSize();
    const float halfWidth = 25.f;   

    for (int i = 0; i + 1 < size; ++i) {
        float ax = path[i].x, ay = path[i].y;
        float bx = path[i + 1].x, by = path[i + 1].y;

        float dx = bx - ax, dy = by - ay;
        float lenSq = dx * dx + dy * dy;
        float t = 0.f;
        if (lenSq > 0.f)
            t = ((mx - ax) * dx + (my - ay) * dy) / lenSq;
        if (t < 0.f) t = 0.f;
        if (t > 1.f) t = 1.f;

        float closestX = ax + t * dx;
        float closestY = ay + t * dy;
        float distX = mx - closestX;
        float distY = my - closestY;

        if (distX * distX + distY * distY < halfWidth * halfWidth)
            return true;
    }
    return false;
}

int Game::towerCost(TowerType t) const
{
    switch (t) {
    case TowerType::Cannon: return 125;
    case TowerType::Sniper: return 150;
    case TowerType::MachineGun: return 175;
    case TowerType::Slow: return 100;
    default: return 0;
    }
}

void Game::drawHUD()
{
    if (!mFontLoaded) return;

    RectangleShape hudBox(Vector2f(300.f, 110.f));
    hudBox.setPosition(0.f, 658.f); 
    hudBox.setFillColor(Color(245, 245, 230));
    hudBox.setOutlineColor(Color(0, 0, 0, 180));
    hudBox.setOutlineThickness(2.f);
    mWindow.draw(hudBox);

    Text goldText;
    goldText.setFont(mFont);
    goldText.setCharacterSize(20);
    goldText.setFillColor(Color(180, 140, 0));
    goldText.setPosition(10.f, 665.f);
    char goldBuf[64];
    int g = 0;
    goldBuf[g++] = 'G'; goldBuf[g++] = 'o'; goldBuf[g++] = 'l';
    goldBuf[g++] = 'd'; goldBuf[g++] = ':'; goldBuf[g++] = ' ';
    int tmp = mGold; if (tmp == 0) { goldBuf[g++] = '0'; }
    char digits[12]; int d = 0;
    while (tmp > 0) { digits[d++] = '0' + (tmp % 10); tmp /= 10; }
    for (int i = d - 1; i >= 0; --i) goldBuf[g++] = digits[i];
    goldBuf[g] = '\0';
    goldText.setString(goldBuf);
    mWindow.draw(goldText);

    Text livesText;
    livesText.setFont(mFont);
    livesText.setCharacterSize(20);
    livesText.setFillColor(Color::Red);
    livesText.setPosition(10.f, 690.f);
    char livesBuf[64];
    int l = 0;
    livesBuf[l++] = 'L'; livesBuf[l++] = 'i'; livesBuf[l++] = 'v';
    livesBuf[l++] = 'e'; livesBuf[l++] = 's'; livesBuf[l++] = ':'; livesBuf[l++] = ' ';
    tmp = mLives; if (tmp == 0) { livesBuf[l++] = '0'; }
    d = 0;
    while (tmp > 0) { digits[d++] = '0' + (tmp % 10); tmp /= 10; }
    for (int i = d - 1; i >= 0; --i) livesBuf[l++] = digits[i];
    livesBuf[l] = '\0';
    livesText.setString(livesBuf);
    mWindow.draw(livesText);

    Text waveText;
    waveText.setFont(mFont);
    waveText.setCharacterSize(20);
    waveText.setFillColor(Color(0, 100, 0));
    waveText.setPosition(10.f, 715.f);
    char waveBuf[64];
    int w = 0;
    waveBuf[w++] = 'W'; waveBuf[w++] = 'a'; waveBuf[w++] = 'v';
    waveBuf[w++] = 'e'; waveBuf[w++] = ':'; waveBuf[w++] = ' ';
    tmp = mCurrentWave; if (tmp == 0) { waveBuf[w++] = '0'; }
    d = 0;
    while (tmp > 0) { digits[d++] = '0' + (tmp % 10); tmp /= 10; }
    for (int i = d - 1; i >= 0; --i) waveBuf[w++] = digits[i];
    waveBuf[w] = '\0';
    waveText.setString(waveBuf);
    mWindow.draw(waveText);

    Text selText;
    selText.setFont(mFont);
    selText.setCharacterSize(16);
    selText.setFillColor(Color(0, 0, 180));
    selText.setPosition(10.f, 740.f);
    switch (mSelectedType) {
    case TowerType::Cannon: selText.setString("[1] Cannon $125"); break;
    case TowerType::Sniper: selText.setString("[2] Sniper $150"); break;
    case TowerType::MachineGun: selText.setString("[3] MachineGun $175"); break;
    case TowerType::Slow: selText.setString("[4] Slow $100"); break;
    default: break;
    }
    mWindow.draw(selText);
}

