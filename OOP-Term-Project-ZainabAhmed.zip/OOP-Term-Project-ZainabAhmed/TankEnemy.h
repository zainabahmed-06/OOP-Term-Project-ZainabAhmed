#pragma once
#include <SFML/Graphics.hpp>
#include "Enemy.h"

class TankEnemy : public Enemy {
private:
    int armor;

public:
    TankEnemy(float startX, float startY);

    int  getArmor() const;
    void move() override;
    void move(float deltaTime) override;
    void takeDamage(int damage) override;
    void render(RenderWindow& window) override;

    ~TankEnemy();
};