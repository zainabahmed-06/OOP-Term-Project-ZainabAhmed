#include "FlyingEnemy.h"
using namespace std;
using namespace sf;

FlyingEnemy::FlyingEnemy(float startX, float startY, float exitX, float exitY): Enemy(startX, startY, "FlyingEnemy", 60, 130.0f, 20), exitX(exitX), exitY(exitY) {}

void FlyingEnemy::setExitPoint(float ex, float ey)
{
    exitX = ex;
    exitY = ey;
}

void FlyingEnemy::move()
{
    move(0.016f);
}

void FlyingEnemy::move(float deltaTime)
{
    moveToward(exitX, exitY, deltaTime);

    float dx = exitX - x;
    float dy = exitY - y;
    float distSq = dx * dx + dy * dy;

    if (distSq <= 100.f) {
        hasEscaped = true;
        isAlive = false;
    }
}

void FlyingEnemy::takeDamage(int damage)
{
    Enemy::takeDamage(damage);
}

void FlyingEnemy::render(RenderWindow& window)
{
    if (mTexture != nullptr) {
        mSprite.setPosition(x, y);
        window.draw(mSprite);
    }
    else {
        RectangleShape shape(Vector2f(18.f, 18.f));
        shape.setOrigin(9.f, 9.f);
        shape.setPosition(x, y);
        shape.setRotation(45.f);
        shape.setFillColor(Color(50, 140, 230));
        shape.setOutlineColor(Color(20, 80, 180));
        shape.setOutlineThickness(1.5f);
        window.draw(shape);
    }
    renderHpBar(window);
}

FlyingEnemy::~FlyingEnemy() {}