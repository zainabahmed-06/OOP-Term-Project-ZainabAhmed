#include "TankEnemy.h"
#include "Tower.h"
using namespace std;
using namespace sf;

TankEnemy::TankEnemy(float startX, float startY): Enemy(startX, startY, "TankEnemy", 200, 50.0f, 30), armor(10) {}

int TankEnemy::getArmor() const
{
    return armor;
}

void TankEnemy::move()
{
    move(0.016f);
}

void TankEnemy::move(float deltaTime)
{
    if (waypointCount == 0) return;
    if (waypointIndex >= waypointCount) {
        hasEscaped = true;
        isAlive = false;
        return;
    }
    float targetX = waypoints[waypointIndex].x;
    float targetY = waypoints[waypointIndex].y;
    moveToward(targetX, targetY, deltaTime);
    if (isAtWaypoint(targetX, targetY))
        waypointIndex++;
}

void TankEnemy::takeDamage(int damage)
{
    int reducedDamage = damage - armor;
    if (reducedDamage < 0) reducedDamage = 0;
    Enemy::takeDamage(reducedDamage);
}

void TankEnemy::render(RenderWindow& window)
{
    if (mTexture != nullptr) {
        mSprite.setPosition(x, y);
        window.draw(mSprite);
    }
    else {
        RectangleShape shape(Vector2f(28.f, 28.f));
        shape.setOrigin(14.f, 14.f);
        shape.setPosition(x, y);
        shape.setFillColor(Color(80, 80, 90));
        shape.setOutlineColor(Color(40, 40, 50));
        shape.setOutlineThickness(2.f);
        window.draw(shape);
    }
    renderHpBar(window);
}

TankEnemy::~TankEnemy() {}