#pragma once
#include <SFML/Graphics.hpp>
#include "Enemy.h"

class FastEnemy : public Enemy {
public:
    FastEnemy(float startX, float startY);

    void move() override;
    void move(float deltaTime) override;
    void takeDamage(int damage) override;
    void render(RenderWindow& window) override;

    ~FastEnemy();
};