#pragma once
#include "Tower.h"

class SniperTower : public Tower {
public:
    SniperTower(float x, float y);

    void attack() override;
    void update(float deltaTime, Enemy** enemies, int count) override;
    void render(RenderWindow& window) override;
    void upgrade() override;

    ~SniperTower();
};