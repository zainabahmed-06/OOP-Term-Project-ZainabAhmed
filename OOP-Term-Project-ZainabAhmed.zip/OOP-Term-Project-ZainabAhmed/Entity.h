#pragma once
#include <iostream>
#include <string>
using namespace std;

class Entity {
protected:
    float x, y;
    string name;
    bool isAlive;

public:
    Entity(float startX, float startY, string entityName);

    virtual void move() = 0;
    virtual void attack() = 0;
    virtual void takeDamage(int damage) = 0;

    virtual string getName() const;
    virtual bool   getIsAlive() const;
    virtual float  getX() const;
    virtual float  getY() const;
    virtual void   setX(float newX);
    virtual void   setY(float newY);
    virtual void   setIsAlive(bool status);

    virtual ~Entity();

    friend ostream& operator<<(ostream& os, const Entity& e);
};