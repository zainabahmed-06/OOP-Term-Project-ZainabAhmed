#include <SFML/Graphics.hpp>
#include "Map.h"
#include "Entity.h"
#include "Enemy.h"
#include "Game.h"
#include <iostream>
using namespace std;
using namespace sf;

int main()
{

    Game game;
    game.run();

    return 0;
}