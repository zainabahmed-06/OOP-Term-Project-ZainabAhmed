#include "SlowTower.h"
#include "Enemy.h"
#include "Tower.h"
#include <cmath>
using namespace std;
using namespace sf;

SlowTower::SlowTower(float x, float y): Tower(x, y, "SlowTower", 120.f, 0, 1.0f, 100),slowMultiplier(0.4f),slowDuration(2.0f) {}

float SlowTower::getSlowMultiplier() const { return slowMultiplier; }
float SlowTower::getSlowDuration() const { return slowDuration; }

void SlowTower::attack() {}  

void SlowTower::update(float deltaTime, Enemy** enemies, int count)
{
    if (fireCooldown > 0.f) {
        fireCooldown -= deltaTime;
        return;
    }

    bool anyInRange = false;

    for (int i = 0; i < count; ++i) {
        if (enemies[i] == nullptr) continue;
        if (!enemies[i]->getIsAlive()) continue;

        float dx = enemies[i]->getX() - x;
        float dy = enemies[i]->getY() - y;
        float dist = sqrt(dx * dx + dy * dy);

        if (dist <= range) {
            enemies[i]->applySlow(slowMultiplier, slowDuration);
            anyInRange = true;
        }
    }
    if (anyInRange) fireCooldown = 1.f / fireRate;
}

void SlowTower::render(RenderWindow& window)
{
    drawRange(window);
    if (mTexture != nullptr) {
        mSprite.setPosition(x, y);
        window.draw(mSprite);
    }
    else {
        CircleShape base(18.f);
        base.setOrigin(18.f, 18.f);
        base.setPosition(x, y);
        base.setFillColor(Color(80, 180, 220));
        base.setOutlineColor(Color(40, 120, 180));
        base.setOutlineThickness(2.f);
        window.draw(base);

        CircleShape inner(9.f);
        inner.setOrigin(9.f, 9.f);
        inner.setPosition(x, y);
        inner.setFillColor(Color(180, 230, 255, 180));
        window.draw(inner);
    }
}

void SlowTower::upgrade()
{
    Tower::upgrade();
    if (slowMultiplier > 0.2f) slowMultiplier -= 0.1f;
    slowDuration += 0.5f;
}

SlowTower::~SlowTower() {}