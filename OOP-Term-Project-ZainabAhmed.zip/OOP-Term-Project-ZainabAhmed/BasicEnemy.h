#pragma once
#include <SFML/Graphics.hpp>
#include "Enemy.h"

class BasicEnemy : public Enemy {
public:
    BasicEnemy(float startX, float startY);

    void move() override;
    void move(float deltaTime)  override;
    void takeDamage(int damage) override;
    void render(RenderWindow& window) override;

    ~BasicEnemy();
};