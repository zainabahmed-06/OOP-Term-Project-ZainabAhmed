﻿#pragma once
#include <SFML/Graphics.hpp>
#include <string>
using namespace sf;
using namespace std;

static const int max_waypoints = 8;
static const int max_enemytypes = 8;
static const int max_towertypes = 8;
static const int max_pathsegments = max_waypoints * 2;

class EnemyTextureEntry {
public:
    char name[32];
    Texture* texture;
};

class TowerTextureEntry {
public:
    char name[32];
    Texture* texture;
};

class Map {
public:
    Map(unsigned int windowWidth, unsigned int windowHeight);
    ~Map();

    bool loadBackground(const string& filePath);

    bool loadEnemyTexture(const string& enemyName, const string& filePath);
    Texture* getEnemyTexture(const string& enemyName);

    bool loadTowerTexture(const string& towerName, const string& filePath);
    Texture* getTowerTexture(const string& towerName);

    void draw(RenderWindow& window);

    const Vector2f* getPath() const;
    int getPathSize() const;
    Vector2f getStartPosition() const;
    Vector2f getExitPosition() const;

private:
    unsigned int mWidth;
    unsigned int mHeight;

    Texture mBackgroundTexture;
    Sprite mBackgroundSprite;
    bool mBackgroundLoaded;

    Vector2f mPathWaypoints[max_waypoints];
    int mWaypointCount;

    RectangleShape mPathSegments[max_pathsegments];
    int mSegmentCount;

    EnemyTextureEntry mEnemyTextures[max_enemytypes];
    int mEnemyTextureCount;

    TowerTextureEntry mTowerTextures[max_towertypes];
    int mTowerTextureCount;

    void buildPath();
    void buildPathVisuals();
};