#include "CannonTower.h"
#include "Enemy.h"
using namespace std;
using namespace sf;

CannonTower::CannonTower(float x, float y): Tower(x, y, "CannonTower", 130.f, 80, 0.6f, 125){}
void CannonTower::attack() {}   
void CannonTower::update(float deltaTime, Enemy** enemies, int count)
{
    if (fireCooldown > 0.f) {
        fireCooldown -= deltaTime;
        return;
    }

    Enemy* target = findTarget(enemies, count);
    if (target == nullptr) return;

    target->takeDamage(damage);
    fireCooldown = 1.f / fireRate;
}

void CannonTower::render(RenderWindow& window)
{
    drawRange(window);
    if (mTexture != nullptr) {
        mSprite.setPosition(x, y);
        window.draw(mSprite);
    }
    else {
        CircleShape base(20.f);
        base.setOrigin(20.f, 20.f);
        base.setPosition(x, y);
        base.setFillColor(Color(60, 60, 70));
        base.setOutlineColor(Color(30, 30, 40));
        base.setOutlineThickness(2.f);
        window.draw(base);

        RectangleShape barrel(Vector2f(28.f, 8.f));
        barrel.setOrigin(0.f, 4.f);
        barrel.setPosition(x, y);
        barrel.setFillColor(Color(40, 40, 50));
        window.draw(barrel);
    }
}

void CannonTower::upgrade()
{
    Tower::upgrade();
    fireRate += 0.1f;
}

CannonTower::~CannonTower() {}