#pragma once
#include "Tower.h"

class SlowTower : public Tower {
private:
    float slowMultiplier;  
    float slowDuration;    

public:
    SlowTower(float x, float y);

    float getSlowMultiplier() const;
    float getSlowDuration() const;

    void attack() override;
    void update(float deltaTime, Enemy** enemies, int count) override;
    void render(RenderWindow& window) override;
    void upgrade() override;

    ~SlowTower();
};